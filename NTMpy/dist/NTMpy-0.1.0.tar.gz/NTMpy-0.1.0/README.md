# Two/ Three Temperature model solver 

[Github-flavored Markdown](https://github.com/udcm-su/heat-diffusion-1D)
